const nodemailer = require('nodemailer');

class EmailService {
  constructor() {
    this.transporter = null;
    this.initializeTransporter();
  }

  initializeTransporter() {
    try {
      // Check required environment variables
      const requiredEnvVars = ['SENDER_EMAIL', 'SERVICE_EMAIL', 'SERVICE_EMAIL_PASSWORD'];
      const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
      
      if (missingVars.length > 0) {
        console.error('Missing required environment variables:', missingVars);
        return;
      }

      console.log('Initializing Gmail SMTP transporter...');
      this.transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: process.env.SERVICE_EMAIL,
          pass: process.env.SERVICE_EMAIL_PASSWORD
        }
      });
      console.log('Gmail SMTP transporter initialized successfully');

      // Verify the transporter
      this.transporter.verify((error, success) => {
        if (error) {
          console.error('Email service verification failed:', error);
          this.transporter = null;
        } else {
          console.log('Email service is ready to send messages');
        }
      });
    } catch (error) {
      console.error('Error initializing email transporter:', error);
      this.transporter = null;
    }
  }

  isConfigured() {
    return !!this.transporter;
  }

  async sendPasswordResetEmail(to, resetLink) {
    if (!this.transporter) {
      throw new Error('Email service is not configured');
    }

    if (!to || !resetLink) {
      throw new Error('Missing required parameters for password reset email');
    }

    const mailOptions = {
      from: process.env.SENDER_EMAIL,
      to,
      subject: 'Password Reset Request',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #333;">Password Reset Request</h2>
          <p>You have requested to reset your password. Click the button below to reset your password:</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${resetLink}" 
               style="background-color: #4CAF50; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">
              Reset Password
            </a>
          </div>
          <p>If you did not request this password reset, please ignore this email.</p>
          <p>This link will expire in 1 hour.</p>
          <hr style="margin: 20px 0; border: none; border-top: 1px solid #eee;">
          <p style="color: #666; font-size: 12px;">
            This is an automated message, please do not reply to this email.
          </p>
        </div>
      `
    };

    try {
      console.log('Sending password reset email to:', to);
      const info = await this.transporter.sendMail(mailOptions);
      console.log('Password reset email sent successfully:', info.messageId);
      return info;
    } catch (error) {
      console.error('Error sending password reset email:', {
        error: error.message,
        code: error.code,
        command: error.command
      });
      throw error;
    }
  }
}

// Create a singleton instance
const emailService = new EmailService();

module.exports = emailService; 