require('dotenv').config();

const config = {
  url: process.env.DATABASE_URL || 'postgres://postgres:62001@localhost:5432/usercomplaint',
  dialect: 'postgres',
  logging: (msg) => {
    if (process.env.NODE_ENV === 'development') {
      console.log('Database Query:', msg);
    }
  },
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  },
  define: {
    timestamps: true,
    underscored: true
  },
  dialectOptions: {
    ssl: process.env.NODE_ENV === 'production' ? {
      require: true,
      rejectUnauthorized: false
    } : false
  }
};

// Log configuration (safely)
console.log('Database Configuration:', {
  url: config.url.replace(/\/\/[^:]+:[^@]+@/, '//****:****@'), // Hide credentials
  dialect: config.dialect,
  logging: !!config.logging,
  ssl: !!config.dialectOptions.ssl
});

// Validate configuration
if (!config.url) {
  console.error('Database URL is not configured!');
  process.exit(1);
}

module.exports = config; 