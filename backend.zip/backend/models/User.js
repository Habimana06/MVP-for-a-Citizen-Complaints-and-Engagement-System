const { Model, DataTypes } = require('sequelize');
const bcrypt = require('bcrypt');

module.exports = (sequelize) => {
  class User extends Model {
    static associate(models) {
      User.hasOne(models.UserProfile, {
        foreignKey: 'userId',
        as: 'profile'
      });
      User.hasMany(models.Complaint, {
        foreignKey: 'userId',
        as: 'complaints'
      });
    }

    async comparePassword(candidatePassword) {
      console.log('Comparing passwords:', {
        candidateLength: candidatePassword.length,
        storedHashLength: this.password.length,
        userId: this.id,
        email: this.email,
        username: this.username
      });
      
      try {
        const isMatch = await bcrypt.compare(candidatePassword, this.password);
        console.log('Password comparison result:', {
          match: isMatch,
          userId: this.id,
          email: this.email,
          username: this.username
        });
        return isMatch;
      } catch (error) {
        console.error('Error in password comparison:', {
          name: error.name,
          message: error.message,
          stack: error.stack,
          userId: this.id,
          email: this.email,
          username: this.username
        });
        throw error;
      }
    }
  }

  User.init({
    username: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        notEmpty: true
      }
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
      validate: {
        isEmail: true
      }
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        len: [6, 100]
      }
    },
    role: {
      type: DataTypes.ENUM('user', 'admin'),
      defaultValue: 'user'
    },
    resetToken: {
      type: DataTypes.STRING,
      allowNull: true
    },
    resetTokenExpiry: {
      type: DataTypes.DATE,
      allowNull: true
    }
  }, {
    sequelize,
    modelName: 'User',
    hooks: {
      beforeCreate: async (user) => {
        if (user.password) {
          console.log('Hashing password for new user:', {
            passwordLength: user.password.length,
            email: user.email,
            username: user.username
          });
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
          console.log('Password hashed successfully:', {
            hashLength: user.password.length,
            email: user.email,
            username: user.username
          });
        }
      },
      beforeUpdate: async (user) => {
        if (user.changed('password')) {
          console.log('Hashing password for update:', {
            passwordLength: user.password.length,
            email: user.email,
            username: user.username
          });
          const salt = await bcrypt.genSalt(10);
          user.password = await bcrypt.hash(user.password, salt);
          console.log('Password hashed successfully:', {
            hashLength: user.password.length,
            email: user.email,
            username: user.username
          });
        }
      }
    }
  });

  return User;
}; 