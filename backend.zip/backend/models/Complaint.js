const { Model, DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  class Complaint extends Model {
    static associate(models) {
      Complaint.belongsTo(models.User, {
        foreignKey: 'userId',
        as: 'user'
      });
    }
  }

  Complaint.init({
    title: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true
      }
    },
    category: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true
      }
    },
    location: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        notEmpty: true
      }
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: false,
      validate: {
        notEmpty: true
      }
    },
    status: {
      type: DataTypes.ENUM('pending', 'in progress', 'resolved', 'rejected'),
      defaultValue: 'pending'
    },
    response: {
      type: DataTypes.TEXT,
      allowNull: true
    },
    submittedDate: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'Users',
        key: 'id'
      }
    }
  }, {
    sequelize,
    modelName: 'Complaint',
    tableName: 'complaints',
    timestamps: true
  });

  return Complaint;
}; 