'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    try {
      // Add resetToken column
      await queryInterface.addColumn('Users', 'resetToken', {
        type: Sequelize.STRING,
        allowNull: true
      });

      // Add resetTokenExpiry column
      await queryInterface.addColumn('Users', 'resetTokenExpiry', {
        type: Sequelize.DATE,
        allowNull: true
      });

      console.log('Successfully added resetToken and resetTokenExpiry columns');
    } catch (error) {
      console.error('Error in migration:', error);
      throw error;
    }
  },

  down: async (queryInterface, Sequelize) => {
    try {
      // Remove resetToken column
      await queryInterface.removeColumn('Users', 'resetToken');

      // Remove resetTokenExpiry column
      await queryInterface.removeColumn('Users', 'resetTokenExpiry');

      console.log('Successfully removed resetToken and resetTokenExpiry columns');
    } catch (error) {
      console.error('Error in migration rollback:', error);
      throw error;
    }
  }
}; 