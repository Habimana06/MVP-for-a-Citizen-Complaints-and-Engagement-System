const express = require('express');
const router = express.Router();
const db = require('../models');
const { body, validationResult } = require('express-validator');
const { auth } = require('../middleware/auth');

// Get all complaints (admin view)
router.get('/admin', auth, async (req, res) => {
  try {
    console.log('Admin complaints request received');
    console.log('Authenticated user:', req.user);

    // Check if user is admin
    if (req.user.role !== 'admin') {
      console.log('Unauthorized access attempt:', {
        userId: req.user.userId,
        role: req.user.role
      });
      return res.status(403).json({ message: 'Not authorized to access admin complaints' });
    }

    const complaints = await db.Complaint.findAll({
      include: [{
        model: db.User,
        as: 'user',
        attributes: ['id', 'username', 'email']
      }],
      order: [['submittedDate', 'DESC']]
    });

    console.log(`Found ${complaints.length} total complaints`);
    res.json(complaints);
  } catch (error) {
    console.error('Error fetching admin complaints:', {
      error: error.message,
      stack: error.stack,
      user: req.user
    });
    res.status(500).json({ 
      message: 'Error fetching complaints',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Get complaints for a specific user
router.get('/user/:userId', auth, async (req, res) => {
  try {
    console.log('Fetching complaints for user:', req.params.userId);
    console.log('Authenticated user:', req.user);
    console.log('Request headers:', req.headers);
    
    // Check if user is authorized to view these complaints
    if (req.user.role !== 'admin' && req.user.userId !== parseInt(req.params.userId)) {
      console.log('Unauthorized access attempt:', {
        requestedUserId: req.params.userId,
        authenticatedUserId: req.user.userId,
        role: req.user.role
      });
      return res.status(403).json({ message: 'Not authorized to view these complaints' });
    }

    console.log('Attempting to find complaints for user:', req.params.userId);
    
    const complaints = await db.Complaint.findAll({
      where: { userId: req.params.userId },
      include: [{
        model: db.User,
        as: 'user',
        attributes: ['id', 'username', 'email']
      }],
      order: [['submittedDate', 'DESC']]
    });

    console.log(`Found ${complaints.length} complaints for user ${req.params.userId}`);
    console.log('Complaints:', JSON.stringify(complaints, null, 2));
    
    res.json(complaints);
  } catch (error) {
    console.error('Error fetching user complaints:', {
      error: error.message,
      stack: error.stack,
      userId: req.params.userId,
      user: req.user,
      errorName: error.name,
      errorCode: error.code
    });
    res.status(500).json({ 
      message: 'Error fetching user complaints',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Create a new complaint
router.post('/', auth, [
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('category').trim().notEmpty().withMessage('Category is required'),
  body('location').trim().notEmpty().withMessage('Location is required'),
  body('description').trim().notEmpty().withMessage('Description is required'),
  body('userId').notEmpty().withMessage('User ID is required'),
  body('email').isEmail().withMessage('Valid email is required')
], async (req, res) => {
  try {
    console.log('Creating complaint request received');
    console.log('Authenticated user:', req.user);

    // Check if user is authorized to create this complaint
    if (req.user.role !== 'admin' && req.user.userId !== parseInt(req.body.userId)) {
      console.log('Unauthorized complaint creation attempt:', {
        requestedUserId: req.body.userId,
        authenticatedUserId: req.user.userId,
        role: req.user.role
      });
      return res.status(403).json({ message: 'Not authorized to create this complaint' });
    }

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('Validation errors:', errors.array());
      return res.status(400).json({ errors: errors.array() });
    }

    console.log('Creating complaint with data:', req.body);
    
    const complaint = await db.Complaint.create({
      ...req.body,
      submittedDate: new Date()
    });

    console.log('Complaint created successfully:', complaint);
    res.status(201).json(complaint);
  } catch (error) {
    console.error('Error creating complaint:', {
      error: error.message,
      stack: error.stack,
      body: req.body,
      user: req.user
    });
    res.status(500).json({ 
      message: 'Error creating complaint',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Update complaint status
router.patch('/:id/status', auth, async (req, res) => {
  try {
    console.log('Status update request received');
    console.log('Authenticated user:', req.user);

    // Check if user is admin
    if (req.user.role !== 'admin') {
      console.log('Unauthorized status update attempt:', {
        userId: req.user.userId,
        role: req.user.role
      });
      return res.status(403).json({ message: 'Only admins can update complaint status' });
    }

    const { status } = req.body;
    const complaint = await db.Complaint.findByPk(req.params.id);
    
    if (!complaint) {
      console.log('Complaint not found:', req.params.id);
      return res.status(404).json({ message: 'Complaint not found' });
    }

    await complaint.update({ status });
    console.log('Complaint status updated:', {
      complaintId: complaint.id,
      newStatus: status
    });
    res.json(complaint);
  } catch (error) {
    console.error('Error updating complaint status:', {
      error: error.message,
      stack: error.stack,
      params: req.params,
      body: req.body,
      user: req.user
    });
    res.status(500).json({ 
      message: 'Error updating complaint status',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Add response to complaint
router.patch('/:id/response', auth, async (req, res) => {
  try {
    console.log('Response update request received');
    console.log('Authenticated user:', req.user);

    // Check if user is admin
    if (req.user.role !== 'admin') {
      console.log('Unauthorized response update attempt:', {
        userId: req.user.userId,
        role: req.user.role
      });
      return res.status(403).json({ message: 'Only admins can add responses' });
    }

    const { response } = req.body;
    const complaint = await db.Complaint.findByPk(req.params.id);
    
    if (!complaint) {
      console.log('Complaint not found:', req.params.id);
      return res.status(404).json({ message: 'Complaint not found' });
    }

    await complaint.update({ response });
    console.log('Complaint response added:', {
      complaintId: complaint.id,
      responseLength: response.length
    });
    res.json(complaint);
  } catch (error) {
    console.error('Error adding response:', {
      error: error.message,
      stack: error.stack,
      params: req.params,
      body: req.body,
      user: req.user
    });
    res.status(500).json({ 
      message: 'Error adding response',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Delete a complaint
router.delete('/:id', auth, async (req, res) => {
  try {
    console.log('Delete request received for complaint:', req.params.id);
    console.log('User from token:', req.user);
    
    if (!req.user || !req.user.userId) {
      console.error('Invalid user data in token');
      return res.status(401).json({ message: 'Invalid authentication token' });
    }

    const complaint = await db.Complaint.findByPk(req.params.id);
    
    if (!complaint) {
      console.log('Complaint not found:', req.params.id);
      return res.status(404).json({ message: 'Complaint not found' });
    }

    console.log('Found complaint:', {
      id: complaint.id,
      userId: complaint.userId,
      status: complaint.status
    });

    // Check if the user is authorized to delete this complaint
    const isAdmin = req.user.role === 'admin';
    const isOwner = req.user.userId === complaint.userId;
    
    console.log('Authorization check:', {
      isAdmin,
      isOwner,
      userRole: req.user.role,
      userId: req.user.userId,
      complaintUserId: complaint.userId
    });

    if (!isAdmin && !isOwner) {
      console.log('User not authorized to delete complaint');
      return res.status(403).json({ message: 'Not authorized to delete this complaint' });
    }

    await complaint.destroy();
    console.log('Complaint deleted successfully:', req.params.id);
    res.json({ message: 'Complaint deleted successfully' });
  } catch (error) {
    console.error('Error deleting complaint:', {
      error: error.message,
      stack: error.stack,
      params: req.params,
      user: req.user
    });
    res.status(500).json({ 
      message: 'Error deleting complaint',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

module.exports = router; 