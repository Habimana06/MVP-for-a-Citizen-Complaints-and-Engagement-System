const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const db = require('../models');
const nodemailer = require('nodemailer');
const nodemailerSendgrid = require('nodemailer-sendgrid');
const emailService = require('../utils/emailService');
const bcrypt = require('bcrypt');
const { Op } = require('sequelize');

// Log environment variables (in development only)
if (process.env.NODE_ENV === 'development') {
  console.log('Environment variables check:');
  console.log('SENDGRID_API_KEY exists:', !!process.env.SENDGRID_API_KEY);
  console.log('SENDER_EMAIL exists:', !!process.env.SENDER_EMAIL);
}

// Create a transporter using SendGrid
let transporter;
try {
  transporter = nodemailer.createTransport(
    nodemailerSendgrid({
      apiKey: process.env.SENDGRID_API_KEY
    })
  );
  console.log('SendGrid transporter created successfully');
} catch (error) {
  console.error('Error creating SendGrid transporter:', error);
}

// Verify email configuration on startup
if (transporter) {
  transporter.verify(function(error, success) {
    if (error) {
      console.error('Email service configuration error:', error);
      console.error('Please check your .env file and ensure:');
      console.error('1. SENDGRID_API_KEY is set correctly');
      console.error('2. You have verified your sender email in SendGrid');
    } else {
      console.log('Email service is ready to send messages');
    }
  });
}

// Register new user
router.post('/register', [
  body('username').trim().notEmpty().withMessage('Username is required'),
  body('email').isEmail().withMessage('Please enter a valid email'),
  body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters long')
], async (req, res) => {
  try {
    console.log('Registration request received:', { ...req.body, password: '[REDACTED]' });
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('Validation errors:', errors.array());
      return res.status(400).json({ errors: errors.array() });
    }

    const { username, email, password } = req.body;

    // Check if user already exists
    const existingUser = await db.User.findOne({ 
      where: {
        [db.Sequelize.Op.or]: [{ email }, { username }]
      }
    });
    
    if (existingUser) {
      console.log('User already exists:', { email, username });
      return res.status(400).json({ message: 'User already exists' });
    }

    // Create new user
    const user = await db.User.create({
      username,
      email,
      password
    });

    console.log('User created successfully:', { id: user.id, username: user.username, email: user.email });

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ 
      message: 'Error registering user',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Login user
router.post('/login', [
  body('email').optional().isEmail().withMessage('Please enter a valid email'),
  body('username').optional().notEmpty().withMessage('Username is required'),
  body('password').notEmpty().withMessage('Password is required')
], async (req, res) => {
  try {
    console.log('Login request received:', { 
      ...req.body, 
      password: '[REDACTED]',
      passwordLength: req.body.password ? req.body.password.length : 0
    });
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('Validation errors:', errors.array());
      return res.status(400).json({ 
        message: 'Validation failed',
        errors: errors.array() 
      });
    }

    const { email, username, password } = req.body;

    if (!email && !username) {
      console.log('Neither email nor username provided');
      return res.status(400).json({ 
        message: 'Either email or username is required' 
      });
    }

    // Find user by email or username
    const whereClause = {
      [Op.or]: []
    };
    
    if (email) whereClause[Op.or].push({ email });
    if (username) whereClause[Op.or].push({ username });

    console.log('Searching for user with:', whereClause);

    try {
      const user = await db.User.findOne({ where: whereClause });
      console.log('User lookup result:', {
        found: !!user,
        id: user?.id,
        email: user?.email,
        username: user?.username,
        hasPassword: !!user?.password,
        passwordLength: user?.password?.length
      });

      if (!user) {
        console.log('User not found:', whereClause);
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      try {
        // Check password
        console.log('Attempting password comparison:', {
          providedPasswordLength: password.length,
          storedHashLength: user.password.length
        });
        const isMatch = await user.comparePassword(password);
        console.log('Password comparison result:', {
          match: isMatch,
          userId: user.id,
          email: user.email,
          username: user.username
        });
        
        if (!isMatch) {
          console.log('Invalid password for user:', { email, username });
          return res.status(401).json({ message: 'Invalid credentials' });
        }
      } catch (error) {
        console.error('Password comparison error:', {
          name: error.name,
          message: error.message,
          stack: error.stack
        });
        throw error;
      }

      // Generate JWT token
      const token = jwt.sign(
        { userId: user.id, role: user.role },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
      );

      console.log('Login successful:', {
        userId: user.id,
        email: user.email,
        username: user.username,
        role: user.role
      });

      res.json({
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role
        }
      });
    } catch (dbError) {
      console.error('Database error:', {
        name: dbError.name,
        message: dbError.message,
        stack: dbError.stack,
        code: dbError.code
      });
      throw dbError;
    }
  } catch (error) {
    console.error('Login error:', {
      name: error.name,
      message: error.message,
      stack: error.stack,
      code: error.code
    });
    res.status(500).json({ 
      message: 'Error logging in',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Forgot password
router.post('/forgot-password', [
  body('email').isEmail().withMessage('Please enter a valid email')
], async (req, res) => {
  try {
    console.log('Forgot password request received:', { email: req.body.email });
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('Validation errors:', errors.array());
      return res.status(400).json({ 
        message: 'Validation failed',
        errors: errors.array() 
      });
    }

    const { email } = req.body;
    console.log('Processing forgot password request for email:', email);

    // Find user by email
    let user;
    try {
      user = await db.User.findOne({ where: { email } });
      console.log('User lookup result:', user ? 'User found' : 'User not found');
    } catch (dbError) {
      console.error('Database error finding user:', dbError);
      throw dbError;
    }

    if (!user) {
      // Return success even if user not found for security
      return res.json({ message: 'If your email is registered, you will receive a password reset link.' });
    }

    // Generate reset token
    let resetToken;
    try {
      resetToken = jwt.sign(
        { userId: user.id, email: user.email, username: user.username },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
      );
      console.log('Reset token generated successfully');
    } catch (tokenError) {
      console.error('Error generating reset token:', tokenError);
      throw tokenError;
    }

    // Save reset token to user
    try {
      await user.update({
        resetToken,
        resetTokenExpiry: Date.now() + 86400000 // 24 hours from now
      });
      console.log('Reset token saved to user record');
    } catch (updateError) {
      console.error('Error updating user with reset token:', updateError);
      throw updateError;
    }

    // Create reset link
    const resetLink = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/reset-password?token=${resetToken}`;
    console.log('Reset link generated:', resetLink);

    try {
      // Check if email service is configured
      if (!emailService.isConfigured()) {
        console.error('Email service not configured. Please check environment variables.');
        // In development, return the reset link directly
        if (process.env.NODE_ENV === 'development') {
          return res.json({ 
            message: 'Email service not configured. Here is your reset link (development only):',
            resetLink 
          });
        }
        throw new Error('Email service not configured');
      }

      await emailService.sendPasswordResetEmail(user.email, resetLink);
      console.log('Password reset email sent successfully to:', user.email);
      res.json({ message: 'If your email is registered, you will receive a password reset link.' });
    } catch (emailError) {
      console.error('Error sending email:', emailError);
      // Clear reset token if email fails
      try {
        await user.update({
          resetToken: null,
          resetTokenExpiry: null
        });
        console.log('Reset token cleared after email error');
      } catch (clearError) {
        console.error('Error clearing reset token:', clearError);
      }

      // In development, return the reset link directly
      if (process.env.NODE_ENV === 'development') {
        return res.json({ 
          message: 'Error sending email. Here is your reset link (development only):',
          resetLink 
        });
      }

      throw emailError;
    }
  } catch (error) {
    console.error('Forgot password error:', {
      message: error.message,
      stack: error.stack,
      code: error.code,
      name: error.name
    });
    res.status(500).json({
      message: 'Error processing forgot password request',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Reset password
router.post('/reset-password', [
  body('token').notEmpty().withMessage('Reset token is required'),
  body('newPassword')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long')
], async (req, res) => {
  try {
    console.log('Reset password request received:', {
      body: { ...req.body, newPassword: '[REDACTED]' },
      headers: req.headers
    });
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('Validation errors:', errors.array());
      return res.status(400).json({ 
        message: 'Validation failed',
        errors: errors.array() 
      });
    }

    const { token, newPassword } = req.body;
    console.log('Processing reset password request with token:', token ? 'Token exists' : 'No token');

    // Verify token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
      console.log('Token verified successfully, decoded:', {
        userId: decoded.userId,
        email: decoded.email,
        username: decoded.username,
        exp: decoded.exp,
        iat: decoded.iat
      });
    } catch (tokenError) {
      console.error('Token verification failed:', {
        name: tokenError.name,
        message: tokenError.message,
        expiredAt: tokenError.expiredAt,
        token: token
      });
      
      if (tokenError.name === 'TokenExpiredError') {
        return res.status(400).json({ 
          message: 'Your password reset link has expired. Please request a new one.',
          code: 'TOKEN_EXPIRED',
          expiredAt: tokenError.expiredAt
        });
      }
      
      return res.status(400).json({ 
        message: 'Invalid reset token. Please request a new password reset link.',
        code: 'INVALID_TOKEN'
      });
    }

    // Find user
    let user;
    try {
      user = await db.User.findOne({
        where: {
          id: decoded.userId,
          email: decoded.email,
          username: decoded.username,
          resetToken: token,
          resetTokenExpiry: {
            [Op.gt]: Date.now()
          }
        }
      });
      console.log('User lookup result:', {
        found: !!user,
        userId: decoded.userId,
        email: decoded.email,
        username: decoded.username,
        tokenMatch: user ? user.resetToken === token : false,
        expiryValid: user ? user.resetTokenExpiry > Date.now() : false,
        currentTime: Date.now(),
        tokenExpiry: user ? user.resetTokenExpiry : null
      });
    } catch (dbError) {
      console.error('Database error finding user:', {
        name: dbError.name,
        message: dbError.message,
        code: dbError.code
      });
      throw dbError;
    }

    if (!user) {
      console.log('User not found or token mismatch for ID:', decoded.userId);
      return res.status(400).json({ 
        message: 'Invalid or expired reset token. Please request a new password reset link.',
        code: 'INVALID_TOKEN'
      });
    }

    // Update user password and clear reset token
    try {
      await user.update({
        password: newPassword,  // Let the model's hooks handle the hashing
        resetToken: null,
        resetTokenExpiry: null
      });
      console.log('Password updated successfully for user:', {
        id: user.id,
        email: user.email,
        username: user.username
      });
    } catch (updateError) {
      console.error('Error updating user password:', {
        name: updateError.name,
        message: updateError.message,
        code: updateError.code
      });
      throw updateError;
    }

    res.json({ 
      message: 'Password has been reset successfully',
      code: 'SUCCESS'
    });
  } catch (error) {
    console.error('Reset password error:', {
      name: error.name,
      message: error.message,
      stack: error.stack,
      code: error.code
    });
    res.status(500).json({
      message: 'Error resetting password',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined,
      code: 'SERVER_ERROR'
    });
  }
});

module.exports = router; 