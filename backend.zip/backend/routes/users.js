const express = require('express');
const router = express.Router();
const db = require('../models');
const { body, validationResult } = require('express-validator');
const { auth } = require('../middleware/auth');

// Validation middleware
const validateProfile = [
  body('fullName')
    .trim()
    .notEmpty().withMessage('Full name is required')
    .isLength({ min: 2, max: 100 }).withMessage('Full name must be between 2 and 100 characters'),
  body('idType')
    .isIn(['nationality', 'passport']).withMessage('Invalid ID type'),
  body('idNumber')
    .trim()
    .notEmpty().withMessage('ID number is required')
    .isLength({ min: 6, max: 20 }).withMessage('ID number must be between 6 and 20 characters'),
  body('phoneNumber')
    .trim()
    .notEmpty().withMessage('Phone number is required')
    .matches(/^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,6}$/).withMessage('Invalid phone number format'),
  body('nationality')
    .trim()
    .notEmpty().withMessage('Nationality is required')
    .isLength({ min: 2, max: 50 }).withMessage('Nationality must be between 2 and 50 characters'),
  body('address')
    .trim()
    .notEmpty().withMessage('Address is required')
    .isLength({ min: 5, max: 500 }).withMessage('Address must be between 5 and 500 characters'),
  body('city')
    .trim()
    .notEmpty().withMessage('City is required')
    .isLength({ min: 2, max: 50 }).withMessage('City must be between 2 and 50 characters'),
  body('country')
    .trim()
    .notEmpty().withMessage('Country is required')
    .isLength({ min: 2, max: 50 }).withMessage('Country must be between 2 and 50 characters')
];

// Create user profile
router.post('/:userId/profile', auth, validateProfile, async (req, res) => {
  try {
    console.log('Profile creation request received:', {
      userId: req.params.userId,
      authenticatedUser: req.user,
      body: req.body
    });
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('Validation errors:', errors.array());
      return res.status(400).json({ errors: errors.array() });
    }

    // Check if user exists
    const user = await db.User.findByPk(req.params.userId);
    console.log('User lookup result:', user ? 'User found' : 'User not found');
    
    if (!user) {
      console.log('User not found:', req.params.userId);
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if profile already exists
    const existingProfile = await db.UserProfile.findOne({
      where: { userId: req.params.userId }
    });

    if (existingProfile) {
      console.log('Profile already exists for user:', req.params.userId);
      return res.status(409).json({ message: 'Profile already exists for this user' });
    }

    // Create profile
    try {
      const profile = await db.UserProfile.create({
        userId: req.params.userId,
        ...req.body
      });

      console.log('Profile created successfully:', profile);
      res.status(201).json(profile);
    } catch (dbError) {
      console.error('Database error creating profile:', dbError);
      if (dbError.name === 'SequelizeValidationError') {
        return res.status(400).json({
          message: 'Validation error',
          errors: dbError.errors.map(err => ({
            msg: err.message,
            field: err.path
          }))
        });
      }
      throw dbError;
    }
  } catch (error) {
    console.error('Error creating profile:', error);
    res.status(500).json({ 
      message: 'Error creating profile',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Get user profile
router.get('/:userId/profile', auth, async (req, res) => {
  try {
    console.log('Profile fetch request received:', {
      userId: req.params.userId,
      authenticatedUser: req.user
    });

    // Check if user exists
    const user = await db.User.findByPk(req.params.userId);
    console.log('User lookup result:', user ? 'User found' : 'User not found');
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const profile = await db.UserProfile.findOne({
      where: { userId: req.params.userId }
    });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    res.json(profile);
  } catch (error) {
    console.error('Error fetching profile:', error);
    res.status(500).json({ 
      message: 'Error fetching profile',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Update user profile
router.put('/:userId/profile', auth, validateProfile, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    // Check if user exists
    const user = await db.User.findByPk(req.params.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const profile = await db.UserProfile.findOne({
      where: { userId: req.params.userId }
    });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    // Update profile
    try {
      await profile.update(req.body);
      
      // Fetch updated profile
      const updatedProfile = await db.UserProfile.findOne({
        where: { userId: req.params.userId }
      });

      res.json(updatedProfile);
    } catch (dbError) {
      console.error('Database error updating profile:', dbError);
      if (dbError.name === 'SequelizeValidationError') {
        return res.status(400).json({
          message: 'Validation error',
          errors: dbError.errors.map(err => ({
            msg: err.message,
            field: err.path
          }))
        });
      }
      throw dbError;
    }
  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ 
      message: 'Error updating profile',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

// Get all users (admin view)
router.get('/admin', auth, async (req, res) => {
  try {
    console.log('Admin users request received');
    console.log('Authenticated user:', req.user);

    // Check if user is admin
    if (req.user.role !== 'admin') {
      console.log('Unauthorized access attempt:', {
        userId: req.user.userId,
        role: req.user.role
      });
      return res.status(403).json({ message: 'Not authorized to access admin users' });
    }

    const users = await db.User.findAll({
      attributes: ['id', 'username', 'email', 'role', 'createdAt'],
      include: [{
        model: db.UserProfile,
        as: 'profile',
        attributes: ['fullName', 'idType', 'idNumber', 'phoneNumber', 'nationality', 'address', 'city', 'country']
      }]
    });

    console.log(`Found ${users.length} total users`);
    res.json(users);
  } catch (error) {
    console.error('Error fetching admin users:', {
      error: error.message,
      stack: error.stack,
      user: req.user
    });
    res.status(500).json({ 
      message: 'Error fetching users',
      error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
  }
});

module.exports = router; 