// Environment Configuration
process.env.NODE_ENV = 'development';
process.env.PORT = '5000';
process.env.JWT_SECRET = 'citizen-engagement-secret-key-2024';

// Database Configuration
process.env.DB_NAME = 'usercomplaint';
process.env.DB_USER = 'postgres';
process.env.DB_PASSWORD = '62001';
process.env.DB_HOST = 'localhost';
process.env.DB_PORT = '5432';

// Email Configuration (Gmail SMTP)
process.env.SENDER_EMAIL = 'hhabimana05@gmail.com';
process.env.SERVICE_EMAIL = 'hhabimana05@gmail.com';
process.env.SERVICE_EMAIL_PASSWORD = 'suhn dbnd gjkm qfgh';

// Frontend URL - Update this to match your frontend application URL
process.env.FRONTEND_URL = 'http://localhost:3000';

// Export configuration for use in other files
module.exports = {
  nodeEnv: process.env.NODE_ENV,
  port: process.env.PORT,
  jwtSecret: process.env.JWT_SECRET,
  db: {
    name: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    host: process.env.DB_HOST,
    port: process.env.DB_PORT
  },
  email: {
    senderEmail: process.env.SENDER_EMAIL,
    serviceEmail: process.env.SERVICE_EMAIL,
    serviceEmailPassword: process.env.SERVICE_EMAIL_PASSWORD
  },
  frontendUrl: process.env.FRONTEND_URL
}; 