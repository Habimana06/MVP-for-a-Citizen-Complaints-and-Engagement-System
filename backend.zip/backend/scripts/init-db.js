const { sequelize } = require('../models');
const bcrypt = require('bcryptjs');

async function initializeDatabase() {
  try {
    // Test database connection
    await sequelize.authenticate();
    console.log('Database connection has been established successfully.');

    // Sync all models
    await sequelize.sync({ force: true }); // This will drop all tables and recreate them
    console.log('Database models synchronized.');

    // Create admin user
    const adminPassword = await bcrypt.hash('admin123', 10);
    await sequelize.models.User.create({
      username: 'admin',
      email: 'admin@example.com',
      password: adminPassword,
      role: 'admin'
    });
    console.log('Admin user created successfully.');

    console.log('Database initialization completed successfully.');
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  } finally {
    await sequelize.close();
  }
}

initializeDatabase(); 