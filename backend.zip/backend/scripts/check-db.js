const { Client } = require('pg');
const config = require('../config/database');

async function checkDatabase() {
  // Extract database name from URL
  const dbName = config.url.split('/').pop();
  const baseUrl = config.url.substring(0, config.url.lastIndexOf('/'));
  
  // Create a client to connect to the default postgres database
  const client = new Client({
    connectionString: baseUrl + '/postgres'
  });

  try {
    await client.connect();
    console.log('Connected to postgres database');

    // Check if our database exists
    const result = await client.query(
      "SELECT 1 FROM pg_database WHERE datname = $1",
      [dbName]
    );

    if (result.rows.length === 0) {
      console.log(`Database ${dbName} does not exist. Creating...`);
      await client.query(`CREATE DATABASE ${dbName}`);
      console.log(`Database ${dbName} created successfully`);
    } else {
      console.log(`Database ${dbName} already exists`);
    }
  } catch (error) {
    console.error('Error checking/creating database:', error);
    process.exit(1);
  } finally {
    await client.end();
  }
}

checkDatabase(); 