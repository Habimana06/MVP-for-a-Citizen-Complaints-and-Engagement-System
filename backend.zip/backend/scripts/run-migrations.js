const { sequelize } = require('../models');
const path = require('path');
const fs = require('fs');

async function runMigrations() {
  try {
    // Test database connection
    console.log('Testing database connection...');
    await sequelize.authenticate();
    console.log('Database connection has been established successfully.');

    // Get all migration files
    const migrationsDir = path.join(__dirname, '..', 'migrations');
    console.log('Looking for migrations in:', migrationsDir);
    
    const migrationFiles = fs.readdirSync(migrationsDir)
      .filter(file => file.endsWith('.js'))
      .sort(); // Ensure migrations run in order

    console.log('Found migration files:', migrationFiles);

    // Create migrations table if it doesn't exist
    try {
      await sequelize.getQueryInterface().createTable('SequelizeMeta', {
        name: {
          type: sequelize.Sequelize.STRING,
          allowNull: false,
          unique: true,
          primaryKey: true
        }
      });
      console.log('Created SequelizeMeta table');
    } catch (error) {
      if (error.name === 'SequelizeUniqueConstraintError') {
        console.log('SequelizeMeta table already exists');
      } else {
        throw error;
      }
    }

    // Get already executed migrations
    const executedMigrations = await sequelize.getQueryInterface().showAllTables()
      .then(tables => {
        if (tables.includes('SequelizeMeta')) {
          return sequelize.query('SELECT name FROM "SequelizeMeta"', { type: sequelize.QueryTypes.SELECT })
            .then(results => results.map(r => r.name));
        }
        return [];
      });

    console.log('Already executed migrations:', executedMigrations);

    // Run each migration
    for (const file of migrationFiles) {
      if (executedMigrations.includes(file)) {
        console.log(`Skipping already executed migration: ${file}`);
        continue;
      }

      console.log(`Running migration: ${file}`);
      const migration = require(path.join(migrationsDir, file));
      
      try {
        await migration.up(sequelize.getQueryInterface(), sequelize.Sequelize);
        await sequelize.query('INSERT INTO "SequelizeMeta" (name) VALUES ($1)', {
          bind: [file],
          type: sequelize.QueryTypes.INSERT
        });
        console.log(`Completed migration: ${file}`);
      } catch (error) {
        console.error(`Error running migration ${file}:`, error);
        throw error;
      }
    }

    console.log('All migrations completed successfully.');
  } catch (error) {
    console.error('Error running migrations:', {
      message: error.message,
      stack: error.stack,
      code: error.code,
      name: error.name
    });
    process.exit(1);
  } finally {
    await sequelize.close();
  }
}

runMigrations(); 