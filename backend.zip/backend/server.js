// Load configuration first
require('./config');

const fs = require('fs');
const path = require('path');
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

// Load environment variables from .env file
console.log('Attempting to load .env file...');
const envPath = path.join(__dirname, '.env');

// Check if .env file exists
if (fs.existsSync(envPath)) {
  console.log(`.env file found at: ${envPath}`);
  const result = dotenv.config({ path: envPath });
  
  if (result.error) {
    console.error('Error loading .env file:', result.error);
  } else {
    console.log('.env file loaded successfully');
  }
} else {
  console.error(`ERROR: .env file not found at: ${envPath}`);
  console.log('Current directory contains:', fs.readdirSync(__dirname));
}

// Set default environment variables
process.env.NODE_ENV = process.env.NODE_ENV || 'development';
process.env.PORT = process.env.PORT || 5000;
process.env.JWT_SECRET = process.env.JWT_SECRET || 'citizen-engagement-secret-key-2024';

// Log all environment variables for debugging (safely)
console.log('Environment check:');
console.log('Current directory:', __dirname);
console.log('NODE_ENV:', process.env.NODE_ENV);
console.log('PORT:', process.env.PORT);
console.log('JWT_SECRET exists:', !!process.env.JWT_SECRET);
console.log('JWT_SECRET length:', process.env.JWT_SECRET ? process.env.JWT_SECRET.length : 0);
console.log('DB_NAME:', process.env.DB_NAME);
console.log('DB_USER:', process.env.DB_USER);
console.log('DB_HOST:', process.env.DB_HOST);

// Log email configuration
console.log('Email configuration:');
console.log('SENDGRID_API_KEY:', process.env.SENDGRID_API_KEY ? 'exists' : 'missing');
console.log('SENDER_EMAIL:', process.env.SENDER_EMAIL ? process.env.SENDER_EMAIL : 'missing');
console.log('SERVICE_EMAIL:', process.env.SERVICE_EMAIL ? process.env.SERVICE_EMAIL : 'missing');
console.log('SERVICE_EMAIL_PASSWORD:', process.env.SERVICE_EMAIL_PASSWORD ? 'exists' : 'missing');
console.log('FRONTEND_URL:', process.env.FRONTEND_URL);

// Setup basic email service - will be enhanced by your full email utility
const configureEmailService = () => {
  if (process.env.SENDGRID_API_KEY && process.env.SENDER_EMAIL) {
    console.log('Using SendGrid for email service');
    return true;
  } else if (process.env.SERVICE_EMAIL && process.env.SERVICE_EMAIL_PASSWORD) {
    console.log('Using SMTP for email service');
    return true;
  } else {
    console.log('No email service configured. Please set up either SendGrid or SMTP credentials.');
    return false;
  }
};

const emailConfigured = configureEmailService();

const { sequelize } = require('./models');
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/complaints', require('./routes/complaints'));
app.use('/api/users', require('./routes/users'));

// Add a test route to check server is working
app.get('/api/test', (req, res) => {
  res.json({ 
    message: 'API is working!',
    emailConfigured,
    environment: process.env.NODE_ENV,
    dbName: process.env.DB_NAME || 'not set'
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ 
    message: 'Something went wrong!',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

const PORT = process.env.PORT || 5000;

// Database connection and server start
async function startServer() {
  try {
    await sequelize.authenticate();
    console.log('Database connection has been established successfully.');
    
    // Sync all models
    await sequelize.sync();
    console.log('Database models synchronized.');

    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
      if (!emailConfigured) {
        console.log('Email service is not configured');
      }
    });
  } catch (error) {
    console.error('Unable to connect to the database:', error);
    process.exit(1);
  }
}

startServer(); 